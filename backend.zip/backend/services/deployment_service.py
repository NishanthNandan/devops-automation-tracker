def calculate_average_deployment_time(deployments):
    total_time = sum(d["duration"] for d in deployments)
    return total_time / len(deployments) if deployments else 0